// Make list sortable
var myList = Sortable.create(columns_list, {
	store: {
		set: function (sortable) {
			make_lst()
		},
	},
});

// add marked checkboxes into hidden variable
function make_lst() {
	var sortedListWithStatus = [];
	myList.toArray().forEach(function(name) {
		var checkbox = document.querySelector('[data-id="' + name + '"] input[type="checkbox"]');
		sortedListWithStatus.push({"n":name, "v": checkbox.checked ? 1 : 0})
	});
	document.getElementById("columnsOrder").value = JSON.stringify(sortedListWithStatus);
}

make_lst()

const select = document.querySelector("#history");
const input = document.querySelector("#query");
const clearQuery = document.querySelector("#clearQuery");
const historyKeyInStorage = "queryHistory";
const allColumnsCheckbox = document.querySelector("#allColumnsCheckbox");
const columnCheckboxes = document.querySelectorAll("#columns_list input[type='checkbox']")


const prependToHistoryAndSave = function() {
	command = document.querySelector("#query").value;
	if (!command) {
		return;
	}
	com_history = JSON.parse(localStorage.getItem(historyKeyInStorage));

	if (!com_history || com_history.length === 0) {
		var newHistory = [];
	}
	else{
		// Create a new list with the command removed
		var newHistory = [...com_history];
		var index = newHistory.indexOf(command);
		if (index !== -1) {
			newHistory.splice(index, 1);
		}
	}
	// Add the command to the beginning of the list
	newHistory.unshift(command);
	// save data
	localStorage.setItem(historyKeyInStorage,JSON.stringify(newHistory));
}

const getColsAndQuery = function(){
	document.querySelector("#returnQueryDelete").value = document.querySelector("#query").value
	document.querySelector("#columnsOrderDelete").value = document.querySelector("#columnsOrder").value
}

const clearHistory = function () {
	localStorage.setItem(historyKeyInStorage,JSON.stringify([]));
	select.innerHTML = "";
}

const history = JSON.parse(localStorage.getItem(historyKeyInStorage));

// Clear the select element
select.innerHTML = "";

// Add an option element for each item in the history array
if (history && history.length>0){
	history.forEach(item => {
		const option = document.createElement("option");
		option.value = item;
		option.text = item;
		select.add(option);
	});
}

select.addEventListener("change", () => {
	input.value = select.value;
});

clearQuery.addEventListener("click", () => {
	input.value = "";
});


columnCheckboxes.forEach( (cbox) => {
	// on change- add marked checkboxes into hidden variable
	cbox.addEventListener("change", make_lst);
	
	cbox.addEventListener("change", () => {
		var markedColumnCheckboxes = document.querySelectorAll("#columns_list input[type='checkbox']:checked")
		console.log(markedColumnCheckboxes.length, columnCheckboxes.length)
		
		if (markedColumnCheckboxes.length == columnCheckboxes.length) {
			allColumnsCheckbox.indeterminate = false;
			allColumnsCheckbox.checked = true;
		}
		else if (markedColumnCheckboxes.length == 0) {
			allColumnsCheckbox.indeterminate = false;
			allColumnsCheckbox.checked = false;
		}
		else if (markedColumnCheckboxes.length > 0) {
			allColumnsCheckbox.indeterminate = true;
		}
	})
})

allColumnsCheckbox.addEventListener("change", () => {
	columnCheckboxes.forEach( (cbox) => {
		cbox.checked = allColumnsCheckbox.checked;
	})
	make_lst()
});
